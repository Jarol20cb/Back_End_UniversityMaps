import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SugerenciaComponent } from './component/sugerencia/sugerencia.component';
import { SugerenciaCrearComponent } from './component/sugerencia/sugerencia-crear/sugerencia-crear.component';
import { DestinoComponent } from './component/destino/destino.component';
import { DestinoCrearComponent } from './component/destino/destino-crear/destino-crear.component';
import { TipodemembresiaComponent } from './component/tipodemembresia/tipodemembresia.component';
import { TipodemembresiaCrearComponent } from './component/tipodemembresia/tipodemembresia-crear/tipodemembresia-crear.component';
import { UniversidadComponent } from './component/universidad/universidad.component';
import { UniversidadCrearComponent } from './component/universidad/universidad-crear/universidad-crear.component';
import { NavComponent } from './component/nav/nav.component';
//import { WelcomePageComponent } from './component/welcome-page/welcome-page.component';
import { PagoComponent } from './component/pago/pago.component';
import { PagoCrearComponent } from './component/pago/pago-crear/pago-crear.component';
import { ProfesorComponent } from './component/profesor/profesor.component';
import { ProfesorCrearComponent } from './component/profesor/profesor-crear/profesor-crear.component';
import { RutaComponent } from './component/ruta/ruta.component';
import { RutaCrearComponent } from './component/ruta/ruta-crear/ruta-crear.component';
import { UbicacionCrearComponent } from './component/ubicacion/ubicacion-crear/ubicacion-crear.component';
import { UbicacionComponent } from './component/ubicacion/ubicacion.component';
import { UbicacionfavoritaCrearComponent } from './component/ubicacionfavorita/ubicacionfavorita-crear/ubicacionfavorita-crear.component';
import { UsuarioCrearComponent } from './component/usuario/usuario-crear/usuario-crear.component';
import { UbicacionfavoritaComponent } from './component/ubicacionfavorita/ubicacionfavorita.component';
import { UsuarioComponent } from './component/usuario/usuario.component';

const routes: Routes = [
  {
    path:'sugerencias', component:SugerenciaComponent, children:[
      {path:'sugerenciacrear',component:SugerenciaCrearComponent},
      {path:'edicionS/:id',component:SugerenciaCrearComponent},
    ]
  },
  {
    path:'destinos',component:DestinoComponent,children:[
      {path:'destinocrear',component:DestinoCrearComponent},
      {path:'edicionD/:id',component:DestinoCrearComponent},
    ]
  },
  {
    path:'membresias',component:TipodemembresiaComponent,children:[
      {path:'membresiacrear',component:TipodemembresiaCrearComponent},
      {path:'edicionM/:id',component:TipodemembresiaCrearComponent},
    ]
  },
  {
    path:'universidades',component:UniversidadComponent,children:[
      {path:'universidadcrear',component:UniversidadCrearComponent},
      {path:'edicionU/:id',component:UniversidadCrearComponent},
    ]
  },
  {
    path:'pagos', component:PagoComponent, children:[
      {path:'pagocrear',component:PagoCrearComponent},
      {path:'edicionP/:id',component:PagoCrearComponent},
    ]
  },
  {
    path:'profesores',component:ProfesorComponent,children:[
      {path:'profesorcrear',component:ProfesorCrearComponent},
      {path:'edicionP/:id',component:ProfesorCrearComponent},
    ]
  },
  {
    path:'rutas',component:RutaComponent,children:[
      {path:'rutacrear',component:RutaCrearComponent},
      {path:'edicionR/:id',component:RutaCrearComponent},
    ]
  },
  {
    path:'ubicaciones',component:UbicacionComponent,children:[
      {path:'ubicacioncrear',component:UbicacionCrearComponent},
      {path:'edicionU/:id',component:UbicacionCrearComponent},
    ]
  },
  {
    path:'ubicacionesfavoritas',component:UbicacionfavoritaComponent,children:[
      {path:'ubicacionfavoritacrear',component:UbicacionfavoritaCrearComponent},
      {path:'edicionU/:id',component:UbicacionfavoritaCrearComponent},
    ]
  },
  {
    path:'usuarios',component:UsuarioComponent,children:[
      {path:'usuariocrear',component:UsuarioCrearComponent},
      {path:'edicionU/:id',component:UsuarioCrearComponent},
    ]
  },
  {path:"nav",component:NavComponent},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
