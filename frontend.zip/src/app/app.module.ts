import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http'
import { SugerenciaComponent } from './component/sugerencia/sugerencia.component';
import { SugerenciaListarComponent } from './component/sugerencia/sugerencia-listar/sugerencia-listar.component';
import { MatTableModule } from '@angular/material/table'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { SugerenciaCrearComponent } from "./component/sugerencia/sugerencia-crear/sugerencia-crear.component";
import { MatNativeDateModule } from '@angular/material/core'
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input'
import { MatSelectModule } from '@angular/material/select'
import { MatDatepickerModule } from '@angular/material/datepicker'
import { MatButtonModule } from '@angular/material/button';
import { UniversidadComponent } from './component/universidad/universidad.component';
import { DestinoComponent } from './component/destino/destino.component';
import { TipodemembresiaComponent } from './component/tipodemembresia/tipodemembresia.component';
import { DestinoListarComponent } from './component/destino/destino-listar/destino-listar.component';
import { DestinoCrearComponent } from './component/destino/destino-crear/destino-crear.component';
import { TipodemembresiaListarComponent } from './component/tipodemembresia/tipodemembresia-listar/tipodemembresia-listar.component';
import { TipodemembresiaCrearComponent } from './component/tipodemembresia/tipodemembresia-crear/tipodemembresia-crear.component';
import { UniversidadListarComponent } from './component/universidad/universidad-listar/universidad-listar.component';
import { UniversidadCrearComponent } from './component/universidad/universidad-crear/universidad-crear.component';
import { NavComponent } from './component/nav/nav.component';
import{MatDialogModule} from '@angular/material/dialog';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import { SugerenciaDialogoComponent } from './component/sugerencia/sugerencia-listar/sugerencia-dialogo/sugerencia-dialogo.component';
import { DestinoDialogoComponent } from './component/destino/destino-listar/destino-dialogo/destino-dialogo.component';
import { TipodemembresiaDialogoComponent } from './component/tipodemembresia/tipodemembresia-listar/tipodemembresia-dialogo/tipodemembresia-dialogo.component';
import { UniversidadDialogoComponent } from './component/universidad/universidad-listar/universidad-dialogo/universidad-dialogo.component';
import { WelcomePageComponent } from './component/welcome-page/welcome-page.component';
import { VistaComponent } from './component/welcome-page/vista/vista.component';
import { NgxPaginationModule } from 'ngx-pagination';  //esta libreria es para la paginacion ----> npm install ngx-pagination --save
import {MatPaginatorModule} from '@angular/material/paginator';
import { PagoComponent } from './component/pago/pago.component';
import { ProfesorComponent } from './component/profesor/profesor.component';
import { RutaComponent } from './component/ruta/ruta.component';
import { UbicacionComponent } from './component/ubicacion/ubicacion.component';
import { UbicacionfavoritaComponent } from './component/ubicacionfavorita/ubicacionfavorita.component';
import { UsuarioComponent } from './component/usuario/usuario.component';
import { PagoListarComponent } from './component/pago/pago-listar/pago-listar.component';
import { PagoCrearComponent } from './component/pago/pago-crear/pago-crear.component';
import { PagoDialogoComponent } from './component/pago/pago-listar/pago-dialogo/pago-dialogo.component';
import { ProfesorListarComponent } from './component/profesor/profesor-listar/profesor-listar.component';
import { ProfesorDialogoComponent } from './component/profesor/profesor-listar/profesor-dialogo/profesor-dialogo.component';
import { RutaListarComponent } from './component/ruta/ruta-listar/ruta-listar.component';
import { RutaDialogoComponent } from './component/ruta/ruta-listar/ruta-dialogo/ruta-dialogo.component';
import { ProfesorCrearComponent } from './component/profesor/profesor-crear/profesor-crear.component';
import { RutaCrearComponent } from './component/ruta/ruta-crear/ruta-crear.component';
import { UbicacionListarComponent } from './component/ubicacion/ubicacion-listar/ubicacion-listar.component';
import { UbicacionDialogoComponent } from './component/ubicacion/ubicacion-listar/ubicacion-dialogo/ubicacion-dialogo.component';
import { UbicacionCrearComponent } from './component/ubicacion/ubicacion-crear/ubicacion-crear.component';
import { UbicacionfavoritaListarComponent } from './component/ubicacionfavorita/ubicacionfavorita-listar/ubicacionfavorita-listar.component';
import { UbicacionfavoritaDialogoComponent } from './component/ubicacionfavorita/ubicacionfavorita-listar/ubicacionfavorita-dialogo/ubicacionfavorita-dialogo.component';
import { UbicacionfavoritaCrearComponent } from './component/ubicacionfavorita/ubicacionfavorita-crear/ubicacionfavorita-crear.component';
import { UsuarioListarComponent } from './component/usuario/usuario-listar/usuario-listar.component';
import { UsuarioDialogoComponent } from './component/usuario/usuario-listar/usuario-dialogo/usuario-dialogo.component';
import { UsuarioCrearComponent } from './component/usuario/usuario-crear/usuario-crear.component';




@NgModule({
  declarations: [
    AppComponent,
    SugerenciaComponent,
    SugerenciaListarComponent,
    SugerenciaCrearComponent,
    UniversidadComponent,
    DestinoComponent,
    TipodemembresiaComponent,
    DestinoListarComponent,
    DestinoCrearComponent,
    TipodemembresiaListarComponent,
    TipodemembresiaCrearComponent,
    UniversidadListarComponent,
    UniversidadCrearComponent,
    NavComponent,
    SugerenciaDialogoComponent,
    DestinoDialogoComponent,
    TipodemembresiaDialogoComponent,
    UniversidadDialogoComponent,
    WelcomePageComponent,
    VistaComponent,
    PagoComponent,
    ProfesorComponent,
    RutaComponent,
    UbicacionComponent,
    UbicacionfavoritaComponent,
    UsuarioComponent,
    PagoListarComponent,
    PagoCrearComponent,
    PagoDialogoComponent,
    ProfesorListarComponent,
    ProfesorDialogoComponent,
    RutaListarComponent,
    RutaDialogoComponent,
    ProfesorCrearComponent,
    RutaCrearComponent,
    UbicacionListarComponent,
    UbicacionDialogoComponent,
    UbicacionCrearComponent,
    UbicacionfavoritaListarComponent,
    UbicacionfavoritaDialogoComponent,
    UbicacionfavoritaCrearComponent,
    UsuarioListarComponent,
    UsuarioDialogoComponent,
    UsuarioCrearComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MatTableModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MatNativeDateModule,
    FormsModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatButtonModule,
    MatToolbarModule,
    MatIconModule,
    MatDialogModule,
    NgxPaginationModule, // Agregar aquí la librería para la paginacion
    MatPaginatorModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
