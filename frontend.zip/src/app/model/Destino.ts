export class Destino{
  idDestino:number=0
  aulaDestino:string=""
  pabellonDestino:string=""
  facultadDestino:string=""
}
