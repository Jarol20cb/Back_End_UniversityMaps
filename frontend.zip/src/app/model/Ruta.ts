import { Destino } from "./Destino"
import { Usuario } from "./Usuario";

export class Ruta{
  idRuta:number=0
  usuario:Usuario=new Usuario();
  destino:Destino=new Destino();
}
