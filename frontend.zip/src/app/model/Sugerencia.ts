import { Usuario } from "./Usuario"

export class Sugerencia{
  idSugerencia:number=0
  descripcionSugerencia:string=""
  usuario:Usuario=new Usuario()
}
