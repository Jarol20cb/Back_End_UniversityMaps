export class TipoDeMembresia{
  idTipoDeMembresia:number=0
  fechainicioTipoDeMembresia:Date=new Date(Date.now())
  fechafinTipoDeMembresia:Date=new Date(Date.now())
  descripcionTipoDeMembresia:string=""
}
