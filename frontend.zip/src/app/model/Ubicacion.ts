import { Universidad } from "./Universidad"

export class Ubicacion{
  idUbicacion:number=0
  descripcionUbicacion:string=""
  universidad:Universidad=new Universidad();
}
