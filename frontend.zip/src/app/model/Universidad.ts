export class Universidad{
  idUniversidad:number=0
  nombreUniversidad:string=""
  regionUniversidad:string=""
  distritoUniversidad:string=""
  calleUniversidad:string=""
  telefonoUniversidad:string=""
}
