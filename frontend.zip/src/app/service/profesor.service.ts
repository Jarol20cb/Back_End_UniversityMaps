import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { environment } from 'src/environment/environment';
import { Profesor } from '../model/Profesor';
const base_url = environment.base

@Injectable({
  providedIn: 'root'
})
export class ProfesorService {
  private url=`${base_url}/profesores`;
  private listCambio=new Subject<Profesor[]>();
  private confirmDelete=new Subject<Boolean>()
  constructor(private http:HttpClient) { }
  list(){
    return this.http.get<Profesor[]>(this.url);
  }
  insert(profesor:Profesor){
    return this.http.post(this.url, profesor);
  }
  setList(listaNueva:Profesor[]){
    this.listCambio.next(listaNueva);
  }
  getList(){
    return this.listCambio.asObservable();
  }
  listId(id:number){
    return this.http.get<Profesor>(`${this.url}/${id}`);
  }
  update(profesor:Profesor){
    //return this.http.put(this.url+'/'+destino.id,destino);
    return this.http.put(this.url, profesor);
  }
  delete(id:number){
    return this.http.delete(`${this.url}/${id}`);
  }
  getConfirmDelete(){
    return this.confirmDelete.asObservable();
  }
  setConfirmDelete(estado:Boolean){
    this.confirmDelete.next(estado);
  }
}
