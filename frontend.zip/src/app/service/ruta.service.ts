import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { environment } from 'src/environment/environment';
import { Ruta } from '../model/Ruta';
import { Destino } from '../model/Destino';
const base_url = environment.base

@Injectable({
  providedIn: 'root'
})
export class RutaService {
  private url=`${base_url}/rutas`;
  private listCambio=new Subject<Ruta[]>();
  private confirmDelete=new Subject<Boolean>()
  constructor(private http:HttpClient) { }
  list(){
    return this.http.get<Ruta[]>(this.url);
  }
  insert(ruta:Ruta){
    return this.http.post(this.url, ruta);
  }
  setList(listaNueva:Ruta[]){
    this.listCambio.next(listaNueva);
  }
  getList(){
    return this.listCambio.asObservable();
  }
  listId(id:number){
    return this.http.get<Ruta>(`${this.url}/${id}`);
  }
  update(ruta:Ruta){
    //return this.http.put(this.url+'/'+destino.id,destino);
    return this.http.put(this.url, ruta);
  }
  delete(id:number){
    return this.http.delete(`${this.url}/${id}`);
  }
  getConfirmDelete(){
    return this.confirmDelete.asObservable();
  }
  setConfirmDelete(estado:Boolean){
    this.confirmDelete.next(estado);
  }
}
