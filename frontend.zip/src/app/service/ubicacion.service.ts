import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { environment } from 'src/environment/environment';
import { Ubicacion } from '../model/Ubicacion';
const base_url = environment.base

@Injectable({
  providedIn: 'root'
})
export class UbicacionService {
  private url=`${base_url}/ubicaciones`;
  private listCambio=new Subject<Ubicacion[]>();
  private confirmDelete=new Subject<Boolean>()
  constructor(private http:HttpClient) { }
  list(){
    return this.http.get<Ubicacion[]>(this.url);
  }
  insert(ubicacion:Ubicacion){
    return this.http.post(this.url, ubicacion);
  }
  setList(listaNueva:Ubicacion[]){
    this.listCambio.next(listaNueva);
  }
  getList(){
    return this.listCambio.asObservable();
  }
  listId(id:number){
    return this.http.get<Ubicacion>(`${this.url}/${id}`);
  }
  update(ubicacion:Ubicacion){
    //return this.http.put(this.url+'/'+destino.id,destino);
    return this.http.put(this.url, ubicacion);
  }
  delete(id:number){
    return this.http.delete(`${this.url}/${id}`);
  }
  getConfirmDelete(){
    return this.confirmDelete.asObservable();
  }
  setConfirmDelete(estado:Boolean){
    this.confirmDelete.next(estado);
  }
}
