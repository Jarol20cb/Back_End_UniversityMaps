import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { environment } from 'src/environment/environment';
import { UbicacionFavorita } from '../model/UbicacionFavorita';
const base_url = environment.base

@Injectable({
  providedIn: 'root'
})
export class UbicacionfavoritaService {
  private url=`${base_url}/ubicacionesfavoritas`;
  private listCambio=new Subject<UbicacionFavorita[]>();
  private confirmDelete=new Subject<Boolean>()
  constructor(private http:HttpClient) { }
  list(){
    return this.http.get<UbicacionFavorita[]>(this.url);
  }
  insert(ubicacionfavorita:UbicacionFavorita){
    return this.http.post(this.url, ubicacionfavorita);
  }
  setList(listaNueva:UbicacionFavorita[]){
    this.listCambio.next(listaNueva);
  }
  getList(){
    return this.listCambio.asObservable();
  }
  listId(id:number){
    return this.http.get<UbicacionFavorita>(`${this.url}/${id}`);
  }
  update(ubicacionfavorita:UbicacionFavorita){
    //return this.http.put(this.url+'/'+destino.id,destino);
    return this.http.put(this.url, ubicacionfavorita);
  }
  delete(id:number){
    return this.http.delete(`${this.url}/${id}`);
  }
  getConfirmDelete(){
    return this.confirmDelete.asObservable();
  }
  setConfirmDelete(estado:Boolean){
    this.confirmDelete.next(estado);
  }
}
