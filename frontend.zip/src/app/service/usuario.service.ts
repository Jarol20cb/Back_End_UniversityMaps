import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environment/environment';
import { Usuario } from '../model/Usuario';
import { Subject } from 'rxjs';
const base_url = environment.base

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {
  private url=`${base_url}/usuarios`;
  private listCambio=new Subject<Usuario[]>();
  private confirmDelete=new Subject<Boolean>()
  constructor(private http:HttpClient) { }
  list(){
    return this.http.get<Usuario[]>(this.url);
  }
  insert(usuario:Usuario){
    console.log(usuario.universidad.idUniversidad);
    return this.http.post(this.url, usuario);
  }
  setList(listaNueva:Usuario[]){
    this.listCambio.next(listaNueva);
  }
  getList(){
    return this.listCambio.asObservable();
  }
  listId(id:number){
    return this.http.get<Usuario>(`${this.url}/${id}`);
  }
  update(usuario:Usuario){
    //return this.http.put(this.url+'/'+destino.id,destino);
    return this.http.put(this.url, usuario);
  }
  delete(id:number){
    return this.http.delete(`${this.url}/${id}`);
  }
  getConfirmDelete(){
    return this.confirmDelete.asObservable();
  }
  setConfirmDelete(estado:Boolean){
    this.confirmDelete.next(estado);
  }
}
